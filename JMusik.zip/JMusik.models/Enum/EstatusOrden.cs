﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JMusik.Models.Enum
{
    public enum EstatusOrden
    {
        Inactivo=0,
        Activo=1
    }
}

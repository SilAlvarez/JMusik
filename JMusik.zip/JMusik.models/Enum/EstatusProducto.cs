﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JMusik.Models.Enum
{
    public enum EstatusProducto
    {
        Inactivo=0,
        Activo=1
    }
}

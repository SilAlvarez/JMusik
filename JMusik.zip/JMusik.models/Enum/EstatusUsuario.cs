﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JMusik.Models.Enum
{
    public enum EstatusUsuario
    {
        Inactivo=0,
        Activo=1
    }
}
